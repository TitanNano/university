﻿using System;

namespace e3
{
	public class Pen
	{
		private int _Color;
		private int _Width;

		public int Color { get { return _Color; } set { _Color = value; }}
		public int Width { get { return _Width; } set { _Width = value; }}
	}
}

