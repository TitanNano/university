public abstract class GeometricalType {
    
	public abstract String toString();

}
